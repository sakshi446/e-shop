// import FeatureProduct from "./components/FeatureProduct";
import HeroSection from "./components/HeroSection";
// import Services from "./components/Services";
// import Trusted from "./components/Trusted";

const Home = () => {
  const data = {
    name: "Upgrad eshop",
  };

  return (
    <>
      <HeroSection myData={data} />
      
    
    </>
  );
};

export default Home;
