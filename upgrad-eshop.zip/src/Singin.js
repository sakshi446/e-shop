import styled from "styled-components";

function validateForm(){
  const fname = document.getElementById("fname").value;
  const lname = document.getElementById("lname").value;
  const mobile = document.getElementById("mobile");
  const email = document.getElementById("email");


  const fnameError = document.getElementById("fname_error");
  const lnameError = document.getElementById("lname_error")
  const mobileError = document.getElementById("mobile_error");
  const emailError = document.getElementById("email_error");

  let isValid = true;

  //-------------------condition----------------

  
 // for first name
  if(fname === ""){
      fnameError.textContent = " **Please enter first name"
      isValid= false;
  }
  else if (!isNaN(fname)) {
      fnameError.textContent = " **Please enter valid name"
      isValid= false;
  } 
  else{
      fnameError.textContent= "";
  }

  // for last name
  if (lname === ""){
      lnameError.textContent =" **Please enter last name";
      isValid = false;
  }
  else if (!isNaN(lname)){
      lnameError.textContent =" **please enter valid name"
      isValid = false;

  }
  else{
      fnameError.textContent = "";
  }

  //for mobile number number
  if (mobile === "") {
      mobileError.textContent = " **Please enter mobile number";
      isValid = false;
  }
else if(!isValidMobile(mobile)){
  mobileError.textContent = " **please enter a valid mobile number";
  isValid = false;
}
else{
  mobileError.textContent = ""
}

//for email 
if (email === "") {
  emailError.textContent = "**please enter email ";
  isValid = false;
} else if (!isValidEmail(email)) {
  emailError.textContent = " ** Invalid email format.";
  isValid = false;
} else {
  emailError.textContent = "";
}

  return isValid;
}

function isValidMobile(mobile){
  const mobilePattern = /^ [0-9] {10}$/;
  return mobilePattern.test(mobile);
}

function isValidEmail(email) {
  const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
  return emailPattern.test(email);
}

let button = fetch("http://localhost:3000")
button.then((value1) =>{
  return value1.json()
}).then((value2) =>{
    console.log(value2);
})

const Singin = () => {
  const Wrapper = styled.section`
  
.form{
  margin-top:100px;
  box-
}
input[type="text"],
input[type="password"] {
  height: 25px;
  border: 1px solid rgba(0, 0, 0, 0.2);
}

label{
  font-size:18px;
}

input[type="submit"] {
  margin-top: 10px;
  cursor: pointer;
  font-size: 15px;
  background: #01d28e;
  border: 1px solid #01d28e;
  color: #fff;
  padding: 10px 20px;
}

input[type="submit"]:hover {
  background: #6cf0c2;
}

.button-container {
  display: flex;
  justify-content: center;
  margin: 0 0 40px
}

.login-form {
  background-color: white;
  padding: 2rem;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

.list-container {
  display: flex;
}

.error {
  color: red;
  font-size: 12px;
}

.title {
  font-size: 25px;
  margin-bottom: 20px;
}

.input-container {
  display: flex;
  justify-content: center;
  flex-direction: column;
  gap: 8px;
  margin-left: 440px;
  margin-bottom:40px;
}

.button-container button{
  padding:6px;
  width:8em;
  background-color:blue;
  color:white;
  border:none;
}

  `;

  return (
    <Wrapper>
      <div className="form">
 <form>
 <div className="input-container">
     <label> First Name</label><br />
     <input type="text" name="uname" id="fname" required />
     <div id="fname_error"style=  {{color: "red", fontsize:" small"}}></div>
     
  </div>

   <div className="input-container">
     <label>Last Name </label><br />
     <input type="text" name="uname" id="lname" required />
     <div id="lname_error"style=  {{color: "red", fontsize:" small"}}></div>

  </div>

  
  <div className="input-container">
     <label>Email Address </label><br />
     <input type="text" name="uname" id="email" required />
     <div id="email_error"style=  {{color: "red", fontsize:" small"}}></div>

  </div>

   <div className="input-container">
     <label>Contact Number  </label><br />
     <input type="text" name="pass" id="mobile" required />
     <div id="mobil_error"style=  {{color: "red", fontsize:" small"}}></div>

   </div>

   <div className="input-container">
     <label>Password </label><br />
     <input type="password" name="pass" required />
   </div>

   <div className="input-container">
     <label>Confirm Password </label><br />
     <input type="password" name="pass" required />
   </div>

   <div className="button-container">
  <button onClick={Singin}>Sing up</button>
   </div>

 </form>
</div>
    </Wrapper>
     
  );
};

export default Singin;
