
import styled from "styled-components";

let button = fetch("http://localhost:3000")
button.then((value1) =>{
  return value1.json()
}).then((value2) =>{
    console.log(value2);
})

const Login = () => {
  return (
  <>
  <Wrapper>

<div className="form">
 <form>
   <div className="input-container">
     <label>Username </label><br />
     <input type="text" name="uname" required />
  </div>

   <div className="input-container">
     <label>Password </label><br />
     <input type="password" name="pass" required />
   </div>

   <div className="button-container">
     <input type="submit" />
   </div>

 </form>
</div>
</Wrapper>
</>


  );

};
const Wrapper = styled.section`

.form{
margin-top:100px;
box-
}
input[type="text"],
input[type="password"] {
height: 25px;
border: 1px solid rgba(0, 0, 0, 0.2);
}

label{
font-size:18px;
}

input[type="submit"] {
margin-top: 10px;
cursor: pointer;
font-size: 15px;
background: #01d28e;
border: 1px solid #01d28e;
color: #fff;
padding: 10px 20px;
}

input[type="submit"]:hover {
background: #6cf0c2;
}

.button-container {
display: flex;
justify-content: center;
}

.login-form {
background-color: white;
padding: 2rem;
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

.list-container {
display: flex;
}

.error {
color: red;
font-size: 12px;
}

.title {
font-size: 25px;
margin-bottom: 20px;
}

.input-container {
display: flex;
justify-content: center;
flex-direction: column;
gap: 8px;
margin-left: 440px;
margin-bottom:40px;
}

`;





export default Login;
