import React from "react";
import { NavLink } from "react-router-dom";
import styled from "styled-components";
import Nav from "./Nav";
import RemoveShoppingCartTwoToneIcon from '@mui/icons-material/RemoveShoppingCartTwoTone';


const Header = () => {
  return (
    <MainHeader>
      <NavLink to="/">
       
        <span><RemoveShoppingCartTwoToneIcon  id="logo" style={{width:"3em",height: "4em", color:"white"}} />  </span>

      </NavLink>
      <Nav />
    </MainHeader>
  );
};

const MainHeader = styled.header`
  padding: 0 4.8rem;
  height: 10rem;
  background-color:  #3f51b5;
  color:white;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: relative;

  .logo {
    height: 5rem;
  }
`;
export default Header;
